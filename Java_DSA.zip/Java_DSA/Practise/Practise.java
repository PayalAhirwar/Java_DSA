import java.util.*;
public class Practise {
public static int printSum(int n) {
    if(n==11) {
        return 0;
    }
    int sum =  printSum(n+1);;
    int tsum = n + sum;
   return tsum;
}
public static void main(String args[]) {
    System.out.println(printSum(0));
}
}
