import java.util.*;

public class Practice {
    public static void main(String args[]) {
        char arr[] = {'a','b','c','d'};
        String str = "abcd";
        String str2 = new String("xyz");

        String name;
        Scanner sc = new Scanner(System.in);
        name = sc.nextLine();
        System.out.println(name);
    }
}